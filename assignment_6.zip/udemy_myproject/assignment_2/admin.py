from django.contrib import admin

# Register your models here.

# Register Book model
from .models import Book

admin.site.register(Book)

