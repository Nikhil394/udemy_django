import models

author = models.Author(name="Nikhil",age=20)