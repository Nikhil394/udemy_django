from django.shortcuts import render

# Create your views here.
# Create a simple view to retrieve and display the Book records in template
from .models import Book

def book_list(request):
    books = Book.objects.all()
    return render(request, 'assignment_2/book_list.html', {'books': books})

def book_details(request, pk):
    book = Book.objects.get(pk=pk)
    return render(request, 'assignment_2/book_details.html', {'book' : book})