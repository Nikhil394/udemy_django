from django.shortcuts import render

# Create your views here.
def layout_view(request):
    return render(request, 'layout.html')