from django.apps import AppConfig


class Assignment7Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'assignment_7'
