# Implement a user registration form using Django’s UserCreationForm in authapp/forms.py. Customize it if necessary to include additional fields.
# Create a view that will render the registration form and process the form submission. The view should create a new user and save it to the database.
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField()
    password1 = forms.CharField(widget=forms.PasswordInput)
    password2 = forms.CharField(widget=forms.PasswordInput)

class UserLoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)