from django import forms

class ContactForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField()
    age = forms.IntegerField(min_value=18, max_value=100)
    message = forms.CharField(widget=forms.Textarea)

    def clean_email(self):
        email = self.cleaned_data['email']
        if not email.endswith('@gmail.com'):
            raise forms.ValidationError('Please enter an email address from gmail.com')
        return email
    
    def clean_age(self):
        age = self.cleaned_data['age']
        if age <18 or age > 100:
            raise forms.ValidationError('Please enter an age between 18 and 100')
        return age
    
    def clean_message(self):
        message = self.cleaned_data['message']
        if len(message) < 10:
            raise forms.ValidationError('Please enter a message with at Least 10 Characters')
        return message